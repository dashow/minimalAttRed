%% Main program
%--------------------------------------------------------------------------
%input�� S=(U,C,D);
%output��a minimal reduct(an optimal solution)
%By Xiaojun Xie ��xiexj@nuaa.edu.cn��
% College of Computer Science and Technology
% Nanjing University of Aeronautics and Astronautics, Nanjing, 211106, China
% Here's my latest research topic��
%(1) X. Xie, X. Qin, A novel incremental attribute reduction approach for dynamic incomplete decision
%    systems, International Journal of Approximate Reasoning 93 (2018) 443-462
%(2) X. Xie, X. Qin, C. Yu, et al., Test-cost-sensitive rough set based approach for minimum weight vertex
%    cover problem, Applied Soft Computing Journal 64 (2018) 423-435
% https://www.sciencedirect.com/science/article/pii/S0888613X17302918
% https://www.sciencedirect.com/science/article/pii/S1568494617307482
%--------------------------------------------------------------------------
clear  
close all
clc
%% Import the data set
[filename,filepath]=uigetfile('*.mat','Select Input file');% Select a data set 
addpath(genpath(filepath));%Add the path
load(filename); % Import the data set
rmpath(genpath(filepath));
%% The optimal solution of minimum attribute reduction (optimal) 
t0=cputime;
M= GetMatrix( C,D );% Obtain the discernibility  matrix
[ opred] = minimalAttRed(M); % Obtaining a minimal reduction
t1=cputime-t0;
str1=['An optimal reduct of data set ' filename ' is: ' num2str(opred)];
str2=['The number of the optimal reduct is: ' num2str(length(opred))];
str3=['The run time of the program is ' num2str(t1) 's'];
disp(str1);
disp(str2);
disp(str3);
%% Fast attribute reduction algorithm based on inconsistent object set (may not be optimal)
t2=cputime;
red=AttReductionInconsistent( C,D ); %
t3=cputime-t2;
str4=['A reduct of data set ' filename  ' based on inconsistent object set ' 'is: ' num2str(red)];
str5=['The number of the optimal reduct is: ' num2str(length(red))];
str6=['The run time of the program is ' num2str(t3) 's'];
disp(str4);
disp(str5);
disp(str6);
%%
