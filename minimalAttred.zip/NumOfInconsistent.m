function [numberClass ] = NumOfInconsistent( C,D)
%% Compute number of inconsistent object set
% Input��C and D
% Output��number of incostent object set
% More about the incostent object set in the following literature��
% X. Xie, X. Qin, A novel incremental attribute reduction approach for dynamic incomplete decision
%                systems, International Journal of Approximate Reasoning 93 (2018) 443-462
% https://www.sciencedirect.com/science/article/pii/S0888613X17302918
%% ------------------------------------------------------------------------------------------
NC=0;
MC=0;
[numOfobject,~]=size(C);
U=ones(1,numOfobject);
if size(C)==0
    NC=length(U)^3;
else
  N=IndOfEquivalentclass( C );
   for j=2:length(N)
       if j~=length(N)
     NC=NC+(N(j)-N(j-1))^2;
       else NC=NC+(N(j)-N(j-1)+1)^2;
       end
   end  
    
end
  M=IndOfEquivalentclass( [C,D] );
   for k=2:length(M)
       if k~=length(M)
     MC=MC+(M(k)-M(k-1))^2;
       else  MC=MC+(M(k)-M(k-1)+1)^2;
       end
   end
 numberClass=NC-MC;
end

