function [ red] = minimalAttRed(M)
%Input: the cell version of discernibility  matrix
%Output: a minimal reduction 
%---Convert cell to matrix
ij=not(cellfun(@isempty,M));
temp=M(ij);
M=temp;
M=cell2mat(M);% Convert cell to matrix
M=unique(M,'rows');% Delete repeated rows in the matrix
%----end
%Construct 0-1 integer programming problem of minimal attribute reduction
Aeq=M;
[m,n]=size(Aeq);
f=ones(n,1);
intcon = 1:n;
beq = ones(1,m);
lb = zeros(n,1);
ub = ones(n,1);
options = optimoptions('intlinprog','Display','off');
[x]=intlinprog(f,intcon,-Aeq,-beq,[],[],lb,ub,options); % intlinprog solver
att=1:n;
red=att(x~=0);% Obtain the optimal solution 
end