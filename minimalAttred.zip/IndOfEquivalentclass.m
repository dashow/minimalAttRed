function Index= IndOfEquivalentclass( C )
%% Compute the index of equivalent class
%Input��C
%Ouput��the index of equivalentclass 
%% --------------------------------
[numOfobject,~]=size(C);
Index=[];
Index(1)=1;
[~,ind]= sortrows(C);
U=ind;
K=2;
for j=2:numOfobject
    A=C(U(j),:);
    B=C(U(j-1),:);
    if(~isequal(A,B))
        Index(K)=j;K=K+1;
    end
end
Index(end+1)=length(U);
end

