function [ reduct ] = AttReductionInconsistent( C,D )
%% Fast attribute reduction algorithm based on inconsistent object set
% Input:  conditional attribute C and decision attribute D 
% Ouput�� a reduct 
% mail��xiexj@nuaa.edu.cn
% More about the incostent object set in the following literature��
% X. Xie, X. Qin, A novel incremental attribute reduction approach for dynamic incomplete decision
%                systems, International Journal of Approximate Reasoning 93 (2018) 443-462
% https://www.sciencedirect.com/science/article/pii/S0888613X17302918
%%-------------------------------------------------------------------------------------------
%% 
[~,Numatt]=size(C);
att=1:Numatt;
inC=NumOfInconsistent(C,D);
red= ComputeCoreAttribute (C,D );
C_R=C(:,red);
inRed=NumOfInconsistent( C_R,D);
cRind=setdiff(att,red);
reduct=red;
if inRed==inC
    return
end
while  inRed~=inC
   for i=1:length(cRind)
       SIGredi(i)=NumOfInconsistent([C_R,C(:,cRind(i))],D);
   end
    [~,K]=min(SIGredi);
      red=union(red,cRind(K));
      C_R=C(:,red);
     cRind(K)=[];
     inRed=NumOfInconsistent( C_R,D);
     if inRed==inC
         break;
     end
     
end
%%
cd=red;
    while ~isempty(cd)
         redcd=setdiff(red,cd(1));
        cd=setdiff(cd,cd(1));
        if NumOfInconsistent( C(:,redcd),D)==NumOfInconsistent( C(:,red),D)
            red=redcd;
        end
    end
    reduct=red;

end

