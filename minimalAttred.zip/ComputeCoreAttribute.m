function coreSet = ComputeCoreAttribute (C,D )
%% Compute core attribute
% Input:  conditional attribute C and decision attribute D 
% Ouput�� core attribute
%   2016.12.8@nuaa
% More about the incostent object set in the following literature��
% X. Xie, X. Qin, A novel incremental attribute reduction approach for dynamic incomplete decision
%                systems, International Journal of Approximate Reasoning 93 (2018) 443-462
% https://www.sciencedirect.com/science/article/pii/S0888613X17302918
%% -------------------------------------------------------------------------------------------
coreSet=[];
[~,n]=size(C);
RC=NumOfInconsistent(C,D);
for i=1:n
    Ci=C;
    Ci(:,i)=[];
     RCi=NumOfInconsistent(Ci,D);
    if(RCi~=RC)
         coreSet=union(coreSet,i);
    end
 end

