function [ distinct_matrix ] = GetMatrix( decision_table,distinct_value_matrix )
%Obtaining the discernibility  matrix
% input: conditional attribute and decision attribute
% output: the cell version of discernibility  matrix
[num_object,num_condition_attr]=size(decision_table);
distinct_matrix=cell(num_object,num_object);
for i=1:num_object
    for j=i+1:num_object
        differ=zeros(1,num_condition_attr);
        if ~isequal(distinct_value_matrix(i,:),distinct_value_matrix(j,:))
            for k=1:num_condition_attr
                if decision_table(i,k)~=decision_table(j,k)
                    differ(k)=1;
                end
            end
        end
        if sum(differ)~=0
        distinct_matrix{i,j}=differ;
        end
    end
end
end